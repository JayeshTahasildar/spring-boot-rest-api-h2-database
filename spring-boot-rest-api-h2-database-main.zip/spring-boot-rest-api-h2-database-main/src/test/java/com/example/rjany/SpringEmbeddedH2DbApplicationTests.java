package com.example.rjany;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEmbeddedH2DbApplicationTests {

	@Test
	void contextLoads() {
	}

}
