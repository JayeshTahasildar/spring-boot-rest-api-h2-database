package com.example.rjany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringEmbeddedH2DbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringEmbeddedH2DbApplication.class, args);
	}

}
